package com.eci.samples.clienteweb;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootAuthUpdatedApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootAuthUpdatedApplication.class, args);
    }

}
